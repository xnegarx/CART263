# **Know Your Iris**

the nature of the project,
 your name, 
any special explanations of how the project works, 


what are you learning about the data???? what is the data set telling you???
how long is a day in each of the planets??

I chose this dataset because first of all i love iris flowers and second of all  i wanted to dabble in the art of classifications species.

 thirdly, when i look at a data like this, or its graph, its hard to grasp the result, its a type of data that is much more enchanting,and exciting once you visualize it
i go as far as to say, the result is not crucial when its fed to it, but when you see it urslef, in the visual format its much more rewarding
to think of 150 flower test subjects.

the result was that while setosa is relatively easier to classify, virginica nad versicolor look more alike 

explaining the visual:
n repeat 
i had the data to repeat i times surrounding the circle.
opacity = average

I think the biggest struggle for me was trying to make the flowers look accurate whilest maintaining the neutralness and clearness of the comparison.
i didnt wanna portray a realisitc flower to take away from the analysis and make the comparison void, yet i wanted something visually stunning. 

steps made to make the comparison more visible and unbiased: 


1. part of this was the color of the flower i though of using noise for each strand of data but i failed so gradient. 
2. the shape of the flower. at first i wanted the individual petals to be exactly the width and length from the data then i realized this will be fundemnetly flawed since the smaller petals will be overlayed twice as much as the bigger once.
so to show the overlap corrently, i could only compare one set of data and have all the circles draw be the exact same size.
3. compare the flowers to each other, to scale.

  

set backs: the big set back for me was that im comparing only one aspect between three flowrs, 
(ive added different colors later, which makes the vidisualization a little bit "lack luster" .but i really liked my idea of visualizing the pedals 
with their exact measurements so i stuck to this data set. 

they also look like iris of the eye which is cool 
