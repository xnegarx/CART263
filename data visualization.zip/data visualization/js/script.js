/**
Title of Project
Author Name

This is a template. You must fill in the title,
author, and this description to match your project!
*/

"use strict";


/**
Description of preload
*/

let table;
let data = [];

let button;
let one = true;
let centerX;
let centerY;

let flowcolorfield = []; // colors
let start = 0;
let inc = 0.1; //increment
let incStart = 0.005; 
let zoff = 0;

function preload() {
table = loadTable("iris.csv", "csv", "header")
}


/**
Description of setup
*/
function setup() {

  colorMode(HSB, 360, 100, 100, 100);
  noStroke();


  button = createButton('Overlayed');
  button.position(50, 200);
  button.mousePressed(all);

  button = createButton('Individual');
  button.position(50, 230);
  button.mousePressed(individual);

  createCanvas(windowWidth, windowHeight);
  background(0);


  for (var r = 0; r < table.getRowCount(); r++) {
    data[r] = new DataPoint(
      table.getString(r, 0),
      parseFloat(table.getString(r, 1)),
      parseFloat(table.getString(r, 2)),
      parseFloat(table.getString(r, 3)),
      parseFloat(table.getString(r, 4)),
      table.getString(r, 5)
    );
  }

  /*for (var r = 0; r < table.getRowCount(); r++){ // Cycle through each row of the table
    data[r] = new DataPoint(table.getString(r, 0), 
                              table.getString(r, 1), 
                              table.getString(r, 2), 
                              table.getString(r, 3),
                              table.getString(r, 4),
                              table.getString(r, 5));
                              // Pass through the values in each row
  } */


  //console.log(table);
  console.log(table.getRowCount() + " total rows in table");
  console.log(table.getColumnCount() + " total columns in table");

  console.log(table.getString(4, 1));
  console.log(table.getString(4, 2));
  console.log(table.getString(4, 3));
  console.log(table.getString(4, 4));
  console.log(table.getString(4, 5));

  // use a nested for loop to cycle through the table's cells
  // for (var r = 0; r < table.getRowCount(); r++){
  //  ellipse(random(500), random(500), 10*parseInt(table.getString(r, 5)));
  // for (var c = 0; c < table.getColumnCount(); c++) {
  // }
  //}

}


function draw() {
  background(0); // Set the background to white


  //radialGradient(width/2, height/2, 0, width/2, height/2, 350, color(140, 100, 100, 100), color(310, 100, 100, 100));
  // ellipse(width/2, height/2, 50, 50); 

  // update noise values for flowcolorfield
  /*let yoff = start;
  for (let y = 0; y < 100; y++) {
    let xoff = start; // restart xoff for every row
    for (let x = 0; x < 120; x++) {
      //console.log('bye');
      let index = x + y * 120;
      let r = noise(xoff, yoff, start) * 100; 
      let g = noise(xoff + 100, yoff + 100, start) * 100;
      let b = noise(xoff + 200, yoff + 200, start) * 100;
      flowcolorfield[index] = [r, g, b]; // assign color to index
      xoff += inc; 
    } 
    yoff += inc; 
  } 
  start += incStart; // update start value for next frame */

  for(let i = 0; i < data.length; i++) {
    data[i].drawSetosa()
    data[i].drawVersicolor()
    data[i].drawVirginica()
  }
}

class DataPoint {
  constructor(Id, SepalLength, SepalWidth, PetalLength, PetalWidth, Species) {

    // Add each data point to the object
    this.SepalLength = SepalLength;
    this.SepalWidth = SepalWidth;
    this.PetalWidth = PetalWidth;

    this.Id = Id;
    this.PetalLength = PetalLength;
    this.Species = Species;

    this.x;
    this.y;

  }

  drawSetosa() {

    let numPoints = 20;

    let scale = 90;
    let min = 1;

    if (one) {
      one = true;
      centerX = width*1.5/8;
      centerY = height/2;
    } else {
      centerX = width/2;
      centerY = height/2;
    } 

   // for (let r = 0; r < data.length; r++)
   // for (var r = 0; r < table.getRowCount(); r++) {
    if (this.Species === 'Iris-setosa') {
      //console.log('hello');
      let radius = this.PetalLength * scale
      // console.log(radius);
      for (let i = 0; i < numPoints; i++) {
        let angle = i * TWO_PI / numPoints;
        //60
        //0< a <60
        this.x = centerX + (radius-scale*min) * cos(angle);
        this.y = centerY + (radius-scale*min) * sin(angle);
        noStroke();
        //drawingContext.filter = 'blur('+String(random(20))+'px)'; // glow
        //fill(400, 100, 100, 10);
        radialGradient(this.x, this.y, 0, this.x, this.y, 9, color(140, 100, 100, 5), color(310, 100, 100, 5));
       

        let dis = dist(mouseX, mouseY,this.x, this.y);
        if (dis < 3) {
          console.log('name');
          fill(255);
          noStroke();
          circle(this.x, this.y, 10);
          text('Setosa', this.x + 5, this.y)
          text(this.PetalLength, this.x + 7, this.y-10)
          
        } else {
          circle(this.x, this.y, 10);
        }
      }    
    }
  }
  
  drawVersicolor() {
    // center of the canvas  
    let numPoints = 20;



    let scale = 90;
    //let min = 3;
    let min = 1;

    if (one) {
      one = true;
      centerX = width*3.5/8;
      centerY = height/2;
    } else {
      centerX = width/2;
      centerY = height/2;
    } 
      

    if (this.Species === 'Iris-versicolor') {

      let radius = this.PetalLength * scale
      // console.log(radius);
      // loop through the points and draw them
     for (let i = 0; i < numPoints; i++) {
        // calculate the angle for this point
        let angle = i * TWO_PI / numPoints;
        //180
        //0< a< 180
        this.x = centerX + (radius-scale*min) * cos(angle);
        this.y = centerY + (radius-scale*min) * sin(angle);
        // calculate the x and y coordinates for this point
        // draw the point
        noStroke();
        // fill(73, 73, 244, 40);
        radialGradient(this.x, this.y, 0, this.x, this.y, 9, color(140, 100, 100, 5), color(310, 100, 100, 5));

        let dis = dist(mouseX, mouseY,this.x, this.y);
        if (dis < 3) {
          console.log('name');
          fill(255);
          noStroke();
          circle(this.x, this.y, 15);
          text('Versicolor', this.x + 7, this.y+25)
          text(this.PetalLength, this.x+10, this.y+15)
          
        } else {
          circle(this.x, this.y, 15);
        }
      }
    }
  }

  drawVirginica() {
    // center of the canvas
    let numPoints = 20;

    let scale = 90;
    //let min = 4.5
    //let min = 0;
    let min = 1;
   // let centerX;
   // let centerY;

    //let index = this.x + this.y * 120;
    // let c = flowcolorfield[index]; // color is applied to each particle with a specific index

    if (one) {
      one = true;
      centerX = width*6.5 / 8;
      centerY = height / 2;
    } else {
      centerX = width/2;
      centerY = height/2;
    } 

    // radius of the points
    // number of points to draw

    if (this.Species === 'Iris-virginica') {
      let radius = this.PetalLength * scale
         
      // loop through the points and draw them

     // var space = 0.1
      for (let i = 0; i < numPoints; i++) {
        //  rotate(ellipse);
        let angle = i * TWO_PI / numPoints; // calculate the angle for this point
        // calculate the x and y coordinates for this point
        //270
        //4.5
       // 0< a < 60*(min golbarg)
       // 0 < b < 60
        this.x = centerX +  (radius-scale*min) * cos(angle);
        this.y = centerY +  (radius-scale*min) * sin(angle);

        // draw the point
        noStroke();
        // fill(red, green, blue, 30);

        //let index = floor(map(this.x, 0, width, 0, data)) + floor(map(this.y, 0, height, 0, data));

        /* if (c) {

          stroke(color(c[0], c[1], c[2], 30));
          console.log('rang'); 
        } */

       /* let angleFromCenter = atan2(this.y - centerY,this.x - centerX);
        push();
        translate(this.x, this.y);
        rotate(angleFromCenter + HALF_PI);
        //ellipse(0, 0, 10, 30);
        circle(0, 0, 15, 15);
        pop(); */

        radialGradient(this.x-1, this.y-5, 0, this.x-1, this.y-5, 9, color(140, 100, 100, 5), color(310, 100, 100, 5));
        let dis = dist(mouseX, mouseY,this.x, this.y);
        if (dis < 3) {
          //console.log('name');
          fill(255);
          noStroke();
          circle(this.x, this.y, 15);
          text('Virginica', this.x - 40, this.y+20)
          text(this.PetalLength, this.x-35, this.y+10)
          
        } else {
          circle(this.x, this.y, 15);
        }
      } 
    }
  }
}

/**
Description of draw(
*/


function all() {
  one = false;
} 

function individual() {
  one = true;
} 

function radialGradient(sX, sY, sR, eX, eY, eR, colorS, colorE) {
  let gradient = drawingContext.createRadialGradient(
    sX, sY, sR, eX, eY, eR
  );
  gradient.addColorStop(0, colorS);
  gradient.addColorStop(1, colorE);

  drawingContext.fillStyle = gradient;
}